using Microsoft.AspNetCore.Mvc;
 
namespace BookStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
    }
}