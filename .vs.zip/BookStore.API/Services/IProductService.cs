

namespace BookStore.API.Services
{
    public interface IProductService
    {
        
    }
}