

namespace BookStore.API.Services
{
    public class ProductService
    {
        
    }
}