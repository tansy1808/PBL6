

namespace BookStore.API.Services
{
    public interface ICartService
    {
        
    }
}